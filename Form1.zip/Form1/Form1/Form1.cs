namespace Form1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void calcBt_Click(object sender, EventArgs e)
        {
            int a, b, c;
            a = Convert.ToInt32(aTb.Text);
            b = Convert.ToInt32(bTb.Text);
            c = Convert.ToInt32(cTb.Text);

            double delta = b * b - 4 * a * c;

            deltaLb.Text = Convert.ToString(delta);

            if (delta > 0)
            {
                msgLb.Text = ("Existem 2 resultados");
            }
            else if (delta == 0)
            {
                msgLb.Text = ("Existe 1 resultado");
            }
            else if (delta < 0)
            {
                msgLb.Text = ("N�o existe resultados");
            }
             
        }
    }
}
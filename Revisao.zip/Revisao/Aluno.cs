using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Revisao
{
    public struct Aluno
    {
        //prop -> tab
        public string nome { get; set; }

        public decimal nota { get; set; }
    }
}
﻿namespace Form1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.aTb = new System.Windows.Forms.TextBox();
            this.bTb = new System.Windows.Forms.TextBox();
            this.cTb = new System.Windows.Forms.TextBox();
            this.calcBt = new System.Windows.Forms.Button();
            this.deltaLb = new System.Windows.Forms.Label();
            this.msgLb = new System.Windows.Forms.Label();
            this.x1Lb = new System.Windows.Forms.Label();
            this.x2Lb = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // aTb
            // 
            this.aTb.Location = new System.Drawing.Point(49, 12);
            this.aTb.Name = "aTb";
            this.aTb.Size = new System.Drawing.Size(100, 23);
            this.aTb.TabIndex = 0;
            // 
            // bTb
            // 
            this.bTb.Location = new System.Drawing.Point(49, 53);
            this.bTb.Name = "bTb";
            this.bTb.Size = new System.Drawing.Size(100, 23);
            this.bTb.TabIndex = 1;
            // 
            // cTb
            // 
            this.cTb.Location = new System.Drawing.Point(49, 101);
            this.cTb.Name = "cTb";
            this.cTb.Size = new System.Drawing.Size(100, 23);
            this.cTb.TabIndex = 2;
            // 
            // calcBt
            // 
            this.calcBt.Location = new System.Drawing.Point(49, 147);
            this.calcBt.Name = "calcBt";
            this.calcBt.Size = new System.Drawing.Size(75, 23);
            this.calcBt.TabIndex = 3;
            this.calcBt.Text = "Calcular";
            this.calcBt.UseVisualStyleBackColor = true;
            this.calcBt.Click += new System.EventHandler(this.calcBt_Click);
            // 
            // deltaLb
            // 
            this.deltaLb.AutoSize = true;
            this.deltaLb.Location = new System.Drawing.Point(49, 200);
            this.deltaLb.Name = "deltaLb";
            this.deltaLb.Size = new System.Drawing.Size(34, 15);
            this.deltaLb.TabIndex = 4;
            this.deltaLb.Text = "Delta";
            this.deltaLb.Click += new System.EventHandler(this.label1_Click);
            // 
            // msgLb
            // 
            this.msgLb.AutoSize = true;
            this.msgLb.Location = new System.Drawing.Point(49, 230);
            this.msgLb.Name = "msgLb";
            this.msgLb.Size = new System.Drawing.Size(66, 15);
            this.msgLb.TabIndex = 5;
            this.msgLb.Text = "Mensagem";
            // 
            // x1Lb
            // 
            this.x1Lb.AutoSize = true;
            this.x1Lb.Location = new System.Drawing.Point(49, 259);
            this.x1Lb.Name = "x1Lb";
            this.x1Lb.Size = new System.Drawing.Size(19, 15);
            this.x1Lb.TabIndex = 6;
            this.x1Lb.Text = "x1";
            // 
            // x2Lb
            // 
            this.x2Lb.AutoSize = true;
            this.x2Lb.Location = new System.Drawing.Point(49, 288);
            this.x2Lb.Name = "x2Lb";
            this.x2Lb.Size = new System.Drawing.Size(19, 15);
            this.x2Lb.TabIndex = 7;
            this.x2Lb.Text = "x2";
            this.x2Lb.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(25, 15);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 15);
            this.label5.TabIndex = 8;
            this.label5.Text = "A:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(26, 56);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(17, 15);
            this.label6.TabIndex = 9;
            this.label6.Text = "B:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(26, 104);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(18, 15);
            this.label7.TabIndex = 10;
            this.label7.Text = "C:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.x2Lb);
            this.Controls.Add(this.x1Lb);
            this.Controls.Add(this.msgLb);
            this.Controls.Add(this.deltaLb);
            this.Controls.Add(this.calcBt);
            this.Controls.Add(this.cTb);
            this.Controls.Add(this.bTb);
            this.Controls.Add(this.aTb);
            this.Name = "Form1";
            this.Text = "Formula de Bháskara";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox aTb;
        private TextBox bTb;
        private TextBox cTb;
        private Button calcBt;
        private Label deltaLb;
        private Label msgLb;
        private Label x1Lb;
        private Label x2Lb;
        private Label label5;
        private Label label6;
        private Label label7;
    }
}